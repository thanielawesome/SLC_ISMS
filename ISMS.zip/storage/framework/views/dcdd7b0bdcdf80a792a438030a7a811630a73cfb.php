

 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

  <link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">

  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<?php $__env->startSection('mybody'); ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                        <center style="font-family: Bookman Old Style">
                            <h3 class="text-success">INDIVIDUAL INVENTORY UPDATE FORM</h3>
                        </center> <hr><br>

                        <table class="table table-primary" id="data_table">
                            <thead>
                                <tr>
                                    <td><strong>ID Number</strong></td>
                                    <td><strong>First Name</strong></td>
                                    <td><strong>Middle Name</strong></td>
                                    <td><strong>Last Name</strong></td>
                                    <td><strong>ACTION</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $student_bed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($s->idnumber); ?></td>
                                    <td><?php echo e($s->firstname); ?></td>
                                    <td><?php echo e($s->middlename); ?></td>
                                    <td><?php echo e($s->lastname); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('admin/individual_form_bed?idnumber='.$s->idnumber)); ?>">
                                            <button class="btn btn-success">
                                                EDIT
                                            </button>
                                        </a>
                                    </td>
                                </tr>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            
                        </table>



                           

                        
                </div>
                <!-- End of Main Content -->

           
        </div>
        <!-- End of Content Wrapper -->

    </div>
 <?php $__env->stopSection(); ?>
 <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript">
    $(document).ready( function () {
        $('#data_table').DataTable({
          order: [[0, 'DESC']],
        });
    } );


  </script>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ISMS\resources\views//admin/individual_form.blade.php ENDPATH**/ ?>