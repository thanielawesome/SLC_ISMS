

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

  <link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">

  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <center>
        <?php echo e(session()->get('success')); ?>

        </center>
    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <center>
        <?php echo e(session()->get('error')); ?>

        </center>
    </div>
<?php endif; ?>
<?php $__env->startSection('mybody'); ?>
<div class="container-fluid">
    <div class="jumbotron">
    <form method="post" action="add_course">
        <div class="form-group" name="myform" style="color: black;">
            <label><strong>COURSE NAME:</strong> </label>
            <input type="text" class="form-control" name="course_name" required><br>

            <label><strong>COURSE CODE:</strong> </label>
            <input type="text" class="form-control" name="course_code" required><br>

            <label><strong>DEPARTMENT CODE:</strong> </label>
            <input type="text" class="form-control" name="dept_code" required><br>

        </div>
            <div class="modal-footer">
              <button type="submit" name="submit" class="btn btn-success"><i class="fas fa-user-plus"></i> ADD DEPARTMENT</button>
            </div>
        <?php echo e(csrf_field()); ?>

    </form>
    </button>
</div>
<?php $__env->stopSection(); ?>
  <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript">
    $(document).ready( function () {
        $('#data_table').DataTable({
        "order": [[ 0, 'desc' ]]       
      });
    } );


  </script>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ISMS\resources\views//admin/course.blade.php ENDPATH**/ ?>