

<?php if(isset($success)): ?>
<div class="alert alert-success" role="alert">
  <center>
      <?php echo e($success); ?>

  </center> 
</div>
<?php endif; ?>


<?php if(isset($error)): ?>
<div class="alert alert-danger" role="alert">
  <center>
      <?php echo e($error); ?>

  </center> 
</div>
<?php endif; ?>


<?php $__env->startSection('mybody'); ?>

        
 <div class="container-fluid">

     <form method="post">
        <center style="font-family: Bookman Old Style">
             <h3 class="text-success">REGISTRATION FORM FOR ACTIVITIES OF THE GUIDANCE CENTER</h3>
             <br>
             <h6>School Year:</h6>
        </center> <hr><br>
         <div class="row" required>
            <div class="col">
                <label><strong>ACTIVITY:</strong> </label>
                <input type="text" name="activity" class="form-control">
            </div>
        </div>
            <br>
        <div class="row" required>
            <div class="col">
                <label><strong>DATE:</strong> </label>
                <input type="date" name="date" class="form-control">
            </div>
        </div>
            <br>
        <div class="row" required>
            <div class="col">
                <label><strong>VENUE:</strong> </label>
                <input type="text" name="venue" class="form-control">
            </div>
        </div>
            <br>
        <div class="row" required>
            <div class="col">
                <label><strong>FIRST NAME:</strong> </label>
                <input type="text" name="venue" class="form-control" value="<?php echo e($user_info->fname); ?>">
            </div>

            <div class="col">
                <label><strong>MIDLLE NAME:</strong> </label>
                <input type="text" name="venue" class="form-control"value="<?php echo e($user_info->mname); ?>">
            </div>

            <div class="col">
                <label><strong>LAST NAME:</strong> </label>
                <input type="text" name="venue" class="form-control"value="<?php echo e($user_info->lname); ?>">
            </div>
        </div>
               <br> 
                <button class="btn btn-primary float-right">SUBMIT FORM</button>
                <br> 


    </form>

 </div>



               
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ISMS\resources\views//student/reg_form.blade.php ENDPATH**/ ?>