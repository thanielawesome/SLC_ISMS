
<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <center>
        <?php echo e(session()->get('success')); ?>

        </center>
    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <center>
        <?php echo e(session()->get('error')); ?>

        </center>
    </div>
<?php endif; ?>
<?php $__env->startSection('mybody'); ?>

<div class="container-fluid">
  <div class="jumbotron">
      <div class="form-group">
        <div class="row" required>
            <div class="col">
                <label><strong>First Name:</strong> </label>
                <label><?php echo e($student_info->firstname); ?></label>
            </div>
            <div class="col">
                <label><strong>Middle Name:</strong> </label>
                <label><?php echo e($student_info->middlename); ?></label>
            </div>
            <div class="col">
                <label><strong>Last Name:</strong> </label>
                <label><?php echo e($student_info->lastname); ?></label>
            </div>
        </div><br>

        <div class="row" required>
            <div class="col">
                <label><strong>Id Number:</strong> </label>
                <label><?php echo e($student_info->idnumber); ?></label>
            </div>
            <div class="col">
                <label><strong>Contact Number:</strong> </label>
                <label><?php echo e($student_info->contact_number); ?></label>
            </div>
        </div> <br>

        <div class="row" required>
            <div class="col">
                <label><strong>Grade Level:</strong> </label>
                <label><?php echo e($student_info->grade_level); ?></label>
            </div>
            <div class="col">
                <label><strong>Section:</strong> </label>
                <label><?php echo e($student_info->section); ?></label>
            </div>
        </div> <br>
        <div class="row" required>
            <div class="col">
                <label><strong>Parent/Guardian Name:</strong> </label>
                <label><?php echo e($student_info->guardian_name); ?></label>
            </div>
            <div class="col">
                <label><strong>Contact Number:</strong> </label>
                <label><?php echo e($student_info->pg_contact_number); ?></label>
            </div>
        </div> <br>
      </div>
        <div class="footer float-right">
            <button type="button" class="btn btn-success" data-toggle="modal" data-target="#update">
              <i class="fas fa-user-edit"></i> UPDATE
            </button>

            <!-- Modal -->
            <div class="modal fade" id="update" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">UPDATE PROFILE</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form method="post" action="update_student">
                        <label>FIRST NAME</label>
                        <input class="form-control" name="firstname" value="<?php echo e($student_info->firstname); ?>"><br>
                        <input class="form-control" name="id" value="<?php echo e($student_info->id); ?>" hidden>      

                        <label><strong>Middle Name:</strong> </label>
                        <input class="form-control" name="middlename" value="<?php echo e($student_info->middlename); ?>"><br>

                        <label><strong>Last Name:</strong> </label>
                        <input class="form-control" name="lastname" value="<?php echo e($student_info->lastname); ?>"><br>

                        <label><strong>Id Number:</strong> </label>
                        <input class="form-control" name="idno" value="<?php echo e($student_info->idnumber); ?>"><br>


                        <label><strong>Contact Number:</strong> </label>
                        <input class="form-control" name="contactno" value="<?php echo e($student_info->contact_number); ?>"><br>

                        <label><strong>Grade Level:</strong> </label>
                        <input class="form-control" name="grade" value="<?php echo e($student_info->grade_level); ?>"><br>
           
                        <label><strong>Section:</strong> </label>
                        <input class="form-control" name="section" value="<?php echo e($student_info->section); ?>"><br>
            
                        <label><strong>Parent/Guardian Name:</strong> </label>
                        <input class="form-control" name="pg" value="<?php echo e($student_info->guardian_name); ?>"><br>
            
                        <label><strong>Contact Number:</strong> </label>
                        <input class="form-control" name="pg_cn" value="<?php echo e($student_info->pg_contact_number); ?>"><br>


                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-success"><i class="fas fa-user-edit"></i> Update</button>
                  </div>
                  <?php echo e(csrf_field()); ?>

                    </form>
                  </div>
                </div>
              </div>
            </div>
            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete"><i class="fas fa-trash"></i> DELETE
            </button>

            <!-- Modal -->
            <div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">DELETE STUDENT</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <form method="post" action="delete_student">
                    Are you sure you want to delete <strong><?php echo e($student_info-> firstname); ?> <?php echo e($student_info->lastname); ?></strong>?
                    <input type="" name="id" value="<?php echo e($student_info->id); ?>"  hidden="">
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                  </div>
                  <?php echo e(csrf_field()); ?>

                  </form>
                </div>
              </div>
            </div>
        </div>
  </div>
    
</div>
                   

<?php $__env->stopSection(); ?>
  <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript">
    $(document).ready( function () {
        $('#data_table').DataTable({
        "order": [[ 0, 'desc' ]]       
      });
    } );


  </script>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ISMS\resources\views//admin/bed.blade.php ENDPATH**/ ?>