

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

  <link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">

  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <center>
        <?php echo e(session()->get('success')); ?>

        </center>
    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <center>
        <?php echo e(session()->get('error')); ?>

        </center>
    </div>
<?php endif; ?>
<?php $__env->startSection('mybody'); ?>

<div class="container-fluid">
    <table class="table table-bordered" style="color: BLACK;" id="data_table">
        <thead>
            <tr>
                <td>ID NUMBER</td>
                <td>NAME</td>
                <td>ACTION</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $college; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($c->idnumber); ?></td>
                <td><?php echo e($c->firstname); ?> <?php echo e($c->lastname); ?></td>
                <td>
                    <a href="<?php echo e(url('/admin/view_college?id=')); ?><?php echo e($c->idnumber); ?>">
                        <button class="btn btn-primary">
                            <i class="fas fa-eye"></i> VIEW
                        </button>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        
    </table>
    
</div>
                   

<?php $__env->stopSection(); ?>
  <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

    <script type="text/javascript">
    $(document).ready( function () {
        $('#data_table').DataTable({
        "order": [[ 0, 'desc' ]]       
      });
    } );


  </script>
<?php echo $__env->make('admin/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ISMS\resources\views//admin/sy_college.blade.php ENDPATH**/ ?>